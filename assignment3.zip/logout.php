<?php
/**
 * Created by PhpStorm.
 * User: Bandanaa
 * Date: 7/30/2018
 * Time: 21:35
 */
session_start();
session_unset();
session_destroy();
echo " Log out success " ;
header('Location: '. 'MainPage.html');



