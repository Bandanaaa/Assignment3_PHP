<?php
/**
 * Created by PhpStorm.
 * User: Bandanaa
 * Date: 7/30/2018
 * Time: 21:42
 */

$servername="localhost";
$username="root";
$password="";
$db="php_workshop";

$conn=new mysqli($servername, $username, $password, $db);

if($conn->connect_error){
    die("Connection Failed:" . $conn->connect_error);
}


?>