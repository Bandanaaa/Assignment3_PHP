<?php
/**
 * Created by PhpStorm.
 * User: Bandanaa
 * Date: 7/30/2018
 * Time: 21:40
 */
include_once 'db_connect.php';

if($_POST['submit']=='Register')

{

    $user = $_POST['user'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = " insert into user_table (username,password,email_id) values ( '$user' ,'$password' , '$email' ) ";
    echo $sql;
    $result = mysqli_query ( $con , $sql );
    if ( $result )
    { echo " Registration Successful ";
    }
    else
    { echo " Registration Failed \n Try again ";

    }

}

?>