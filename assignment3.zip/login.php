<?php
/**
 * Created by PhpStorm.
 * User: Bandanaa
 * Date: 7/30/2018
 * Time: 21:31
 */
include_once 'db_connect.php';
session_start();

if(isset($_POST['submit'])){
    $user = $_POST["username"];
    $pass = $_POST["password"];

    $query = "select * from user_table where username = '$user' && password = '$pass'";

    $result = mysqli_query ( $con , $query);
    $count=mysqli_num_rows($result);

    if($count == 1){
        $_SESSION["LoggedIn"] = TRUE;
        header('Location: ' . 'AddClothes.php');
    }else{


        header('Location:' . 'MainPage.html');
        echo 'Invalid Details';
    }
}
else
{
    header('Location:' . 'MainPage.html');
}
?>